package login_dash;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class update_dash extends javax.swing.JInternalFrame {
    String value1, value2, opt1, opt2;

    public update_dash() {
        initComponents();
        upd2.setEnabled(false);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        upd2 = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        upd1 = new javax.swing.JLabel();
        usubmit = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        update_field3 = new javax.swing.JComboBox<>();
        update_field2 = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        upd3 = new javax.swing.JLabel();
        upd4 = new javax.swing.JTextField();

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("RETRIVE");

        setPreferredSize(new java.awt.Dimension(700, 1000));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(700, 1000));

        jPanel2.setBackground(new java.awt.Color(17, 30, 108));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("UPDATE");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(250, 250, 250)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(290, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("CHOOSE A FIELD TO UPDATE DATA:");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setText("ENTER DETAILS FOR UPDATION OF DATA ");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("ENTER DATA OF");

        upd2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        upd2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                upd2ActionPerformed(evt);
            }
        });

        jSeparator3.setForeground(new java.awt.Color(0, 0, 0));

        upd1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        upd1.setText("   ");

        usubmit.setBackground(new java.awt.Color(17, 30, 108));
        usubmit.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        usubmit.setForeground(new java.awt.Color(255, 255, 255));
        usubmit.setText("SUBMIT");
        usubmit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        usubmit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                usubmitMouseClicked(evt);
            }
        });
        usubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usubmitActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("CHOOSE A FIELD TO IDENTIFY RECORD:");

        update_field3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_field3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "FACULTY MENTOR", "TYPE", "LEVEL", "YEAR", "AMOUNT", "ORGANIZATION NAME", "ROLL NO" }));
        update_field3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_field3ActionPerformed(evt);
            }
        });

        update_field2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_field2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "UPDATE FACULTY MENTOR", "UPDATE TYPE", "UPDATE LEVEL", "UPDATE YEAR", "UPDATE AMOUNT", "UPDATE ORGANIZATION NAME", "UPDATE ROLL NO", "DELETE" }));
        update_field2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_field2ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("ENTER DATA TO");

        upd3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        upd3.setText("   ");

        upd4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        upd4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                upd4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jSeparator3)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(253, 253, 253)
                        .addComponent(usubmit, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(154, 154, 154)
                        .addComponent(jLabel5))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(45, 45, 45)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(30, 30, 30)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(update_field2, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(update_field3, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(upd1))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(upd3)))
                        .addGap(122, 122, 122)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(upd2, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(upd4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(update_field2, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(update_field3, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(upd3, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(upd2, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(upd1, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(upd4, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addComponent(usubmit, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 422, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1029, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 12, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void usubmitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usubmitMouseClicked

    }//GEN-LAST:event_usubmitMouseClicked

    private void upd2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_upd2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_upd2ActionPerformed

    private void update_field3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_field3ActionPerformed
        // TODO add your handling code here:
        value2 = update_field3.getSelectedItem().toString();
        upd3.setText(value2);      
        if(!" ".equals(upd3.getText()))
        {
            upd2.setEnabled(true);
        }
    }//GEN-LAST:event_update_field3ActionPerformed

    private void update_field2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_field2ActionPerformed
        // TODO add your handling code here:
        value1 = update_field2.getSelectedItem().toString();
        upd1.setText(value1);      
        if(!" ".equals(upd1.getText()))
        {
            upd4.setEnabled(true);
        }
        if("DELETE".equals(value1))
            upd4.setText("IGNORE FIELD");
    }//GEN-LAST:event_update_field2ActionPerformed

    private void upd4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_upd4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_upd4ActionPerformed

    private void usubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usubmitActionPerformed
        // TODO add your handling code here:
        opt2=upd2.getText();
        opt1=upd4.getText();
        if(true)
        {
            Connection conn=null;
            Statement stmt=null;
            ResultSet rslt=null;
            String sql=null, sql1=null, sql2=null;
            PreparedStatement stamnt=null;
            SimpleDateFormat sd=new SimpleDateFormat("yyyy/MM/dd");
            int f=0;
            try
            {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_project","root","Aveline2003");
                stmt=conn.createStatement();
                switch(value1)
                {
                    case "UPDATE FACULTY MENTOR" -> sql1="update students set faculty_mentor=?";
                    case "UPDATE TYPE" -> sql1="update students set type=?";
                    case "UPDATE LEVEL" -> sql1="update students set level=?";
                    case "UPDATE YEAR" -> sql1="update students set year=?";
                    case "UPDATE AMOUNT" -> sql1="update students set amount=?";
                    case "UPDATE ORGANISATION NAME" -> sql1="update students set organisation_name=?";
                    case "UPDATE ROLL NO" -> sql1="update students set roll_no=?";
                    case "DELETE" -> {sql1="delete from students"; f=1;}
                }
                switch(value2)
                {
                    case "FACULTY MENTOR" -> sql2=" where faculty_mentor=?";
                    case "TYPE" -> sql2=" where type=?";
                    case "LEVEL" -> sql2=" where level=?";
                    case "YEAR" -> sql2=" where year=?";
                    case "AMOUNT" -> sql2=" where amount=?";
                    case "ORGANISATION NAME" -> sql2=" where organisation_name=?";
                    case "ROLL NO" -> sql2=" where roll_no=?";
                }
                sql=sql1+sql2;
                stamnt=conn.prepareStatement(sql);
                if(f==1)
                {
                    stamnt.setString(1,opt2);
                }
                else
                {
                    stamnt.setString(1,opt1);
                    stamnt.setString(2,opt2);
                }
                int status=stamnt.executeUpdate();
                if(status>0)
                    JOptionPane.showMessageDialog(this, "Updated Successfully");
                else
                    JOptionPane.showMessageDialog(this,"Please Try Again!!");
            }
            catch(Exception exc)
            {
                exc.getStackTrace();
            }
            finally
            {
                if(rslt!=null)
                {
                    try {
                        rslt.close();
                    } catch (SQLException ex) {
                        Logger.getLogger(insert_form.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                if(stmt!=null)
                {
                    try {
                        stmt.close();
                    } catch (SQLException ex) {
                        Logger.getLogger(insert_form.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                if(conn!=null)
                {
                    try {
                        conn.close();
                    } catch (SQLException ex) {
                        Logger.getLogger(insert_form.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }
    }//GEN-LAST:event_usubmitActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JLabel upd1;
    private javax.swing.JTextField upd2;
    private javax.swing.JLabel upd3;
    private javax.swing.JTextField upd4;
    private javax.swing.JComboBox<String> update_field2;
    private javax.swing.JComboBox<String> update_field3;
    private javax.swing.JButton usubmit;
    // End of variables declaration//GEN-END:variables
}
