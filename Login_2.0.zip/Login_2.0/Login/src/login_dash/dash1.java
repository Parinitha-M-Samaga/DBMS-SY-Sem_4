package login_dash;
import java.awt.*;
import javax.swing.*;



public class dash1 extends javax.swing.JFrame {
    
    Color DefaultColor,ClickedColor;

    public dash1() {
        initComponents();
        DefaultColor = new Color(17,30,108);
        ClickedColor = new Color(255,255,255);
        
        searchintern.setBackground(DefaultColor);
        retrive.setBackground(DefaultColor);
        update.setBackground(DefaultColor);
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem1 = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        dash_right = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        searchintern = new javax.swing.JLabel();
        update = new javax.swing.JLabel();
        retrive = new javax.swing.JLabel();
        logout = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        insertintern = new javax.swing.JLabel();
        deleteintern = new javax.swing.JLabel();
        insert = new javax.swing.JLabel();
        dash_left = new javax.swing.JPanel();

        jMenuItem1.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("DASHBOARD");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(1000, 650));
        jPanel1.setLayout(null);

        dash_right.setBackground(new java.awt.Color(17, 30, 108));
        dash_right.setPreferredSize(new java.awt.Dimension(300, 1000));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("DASHBOARD");

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("________________________________________________________________");

        searchintern.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        searchintern.setForeground(new java.awt.Color(255, 255, 255));
        searchintern.setText("    SEARCH INTERNSHIP");
        searchintern.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        searchintern.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchinternMouseClicked(evt);
            }
        });

        update.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        update.setForeground(new java.awt.Color(255, 255, 255));
        update.setText("    UPDATE RECORD");
        update.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        update.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                updateMouseClicked(evt);
            }
        });

        retrive.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        retrive.setForeground(new java.awt.Color(255, 255, 255));
        retrive.setText("    RETRIEVE RECORD");
        retrive.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        retrive.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                retriveMouseClicked(evt);
            }
        });

        logout.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        logout.setForeground(new java.awt.Color(255, 255, 255));
        logout.setText("    LOG OUT");
        logout.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutMouseClicked(evt);
            }
        });

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("________________________________________________________________");

        insertintern.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        insertintern.setForeground(new java.awt.Color(255, 255, 255));
        insertintern.setText("    INSERT INTERNSHIP");
        insertintern.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        insertintern.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                insertinternMouseClicked(evt);
            }
        });

        deleteintern.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        deleteintern.setForeground(new java.awt.Color(255, 255, 255));
        deleteintern.setText("    DELETE INTERNSHIP");
        deleteintern.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        deleteintern.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                deleteinternMouseClicked(evt);
            }
        });

        insert.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        insert.setForeground(new java.awt.Color(255, 255, 255));
        insert.setText("    INSERT RECORD");
        insert.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        insert.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                insertMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout dash_rightLayout = new javax.swing.GroupLayout(dash_right);
        dash_right.setLayout(dash_rightLayout);
        dash_rightLayout.setHorizontalGroup(
            dash_rightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(dash_rightLayout.createSequentialGroup()
                .addGroup(dash_rightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(dash_rightLayout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(searchintern, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(retrive, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(update, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(logout, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(insertintern, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(deleteintern, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(insert, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        dash_rightLayout.setVerticalGroup(
            dash_rightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dash_rightLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGap(66, 66, 66)
                .addComponent(insert, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(retrive, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(update, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(insertintern, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(deleteintern, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(searchintern, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(72, 72, 72)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(logout)
                .addContainerGap(376, Short.MAX_VALUE))
        );

        jPanel1.add(dash_right);
        dash_right.setBounds(0, 0, 300, 1000);

        dash_left.setBackground(new java.awt.Color(255, 255, 255));
        dash_left.setPreferredSize(new java.awt.Dimension(700, 1000));

        javax.swing.GroupLayout dash_leftLayout = new javax.swing.GroupLayout(dash_left);
        dash_left.setLayout(dash_leftLayout);
        dash_leftLayout.setHorizontalGroup(
            dash_leftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 700, Short.MAX_VALUE)
        );
        dash_leftLayout.setVerticalGroup(
            dash_leftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1000, Short.MAX_VALUE)
        );

        jPanel1.add(dash_left);
        dash_left.setBounds(300, 0, 700, 1000);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void searchinternMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchinternMouseClicked
        // TODO add your handling code here:
        searchintern sein = new searchintern();
        dash_left.removeAll();
        dash_left.add(sein).setVisible(true);
    }//GEN-LAST:event_searchinternMouseClicked

    private void retriveMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_retriveMouseClicked
        // TODO add your handling code here:
        retrive_dash re = new retrive_dash();
        dash_left.removeAll();
        dash_left.add(re).setVisible(true);
    }//GEN-LAST:event_retriveMouseClicked

    private void updateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateMouseClicked
        // TODO add your handling code here:
        update_dash up = new update_dash();
        dash_left.removeAll();
        dash_left.add(up).setVisible(true);
    }//GEN-LAST:event_updateMouseClicked

    private void logoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMouseClicked
        // TODO add your handling code here:
        int res = JOptionPane.showConfirmDialog(this, "Do you want to Logout?", "Logout confirmation", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if(res == JOptionPane.YES_OPTION)
        {
            Login LoginFrame = new Login();
            LoginFrame.setVisible(true);
            LoginFrame.pack();
            LoginFrame.setLocationRelativeTo(null);
            this.dispose();
        }
    }//GEN-LAST:event_logoutMouseClicked

    private void insertinternMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_insertinternMouseClicked
        // TODO add your handling code here:
        insertintern inin = new insertintern();
        dash_left.removeAll();
        dash_left.add(inin).setVisible(true);
    }//GEN-LAST:event_insertinternMouseClicked

    private void deleteinternMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteinternMouseClicked
        // TODO add your handling code here:
        deleteintern dein = new deleteintern();
        dash_left.removeAll();
        dash_left.add(dein).setVisible(true);
    }//GEN-LAST:event_deleteinternMouseClicked

    private void insertMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_insertMouseClicked
        // TODO add your handling code here:
        insert_form in = new insert_form();
        dash_left.removeAll();
        dash_left.add(in).setVisible(true);
    }//GEN-LAST:event_insertMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel dash_left;
    private javax.swing.JPanel dash_right;
    private javax.swing.JLabel deleteintern;
    private javax.swing.JLabel insert;
    private javax.swing.JLabel insertintern;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel logout;
    private javax.swing.JLabel retrive;
    private javax.swing.JLabel searchintern;
    private javax.swing.JLabel update;
    // End of variables declaration//GEN-END:variables
}
